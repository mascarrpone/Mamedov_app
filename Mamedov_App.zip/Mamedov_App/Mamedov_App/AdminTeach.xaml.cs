﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Mamedov_App.Database;


namespace Mamedov_App
{
    /// <summary>
    /// Логика взаимодействия для AdminTeach.xaml
    /// </summary>
    public partial class AdminTeach : Window
    {
        public ObservableCollection<sotrudniki> sotrudniki { get; set; }
        private VuzEntities context;
        private sotrudniki sotrudnik;
      

        
        public AdminTeach()
        {
            InitializeComponent();
            context = new VuzEntities();
        }
       

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            sotrudniki newsotrudniki = new sotrudniki
            {
                role_id = int.Parse(txtrole.Text),
                familiya = txtfamiliya.Text,
                imya = txtimya.Text,
                otchestvo = txtotchestvo.Text,
                telefon = txtpochta.Text,
                email = txtpochta.Text,
                zarplata = int.Parse(txtzp.Text),
                user_id = int.Parse(txtemp.Text)
            };
            // Поиск сотрудника в базе данных для редактирования
            sotrudniki selectedsot = context.sotrudniki.FirstOrDefault(sot => sot.sotrudnik_id == sotrudnik.sotrudnik_id);
            /*
            * Если работник найден:
            *  - Обновляются свойства работника значениями из нового объекта.
            *  - Если пароль был отредактирован:
            
            */
            if (selectedsot != null)
            {
                selectedsot.role_id = newsotrudniki.role_id;
                selectedsot.familiya = newsotrudniki.familiya;
                selectedsot.imya = newsotrudniki.imya;
                selectedsot.otchestvo = newsotrudniki.otchestvo;
                selectedsot.telefon = newsotrudniki.telefon;
                selectedsot.email = newsotrudniki.email;
                selectedsot.zarplata = newsotrudniki.zarplata;
                selectedsot.user_id = newsotrudniki.user_id;

                try
                {
                    context.SaveChanges();
                    MessageBox.Show("Данные сохранены успешно.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка при сохранении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CleanButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
